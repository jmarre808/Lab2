 #include <stdio.h>

int main()
{
  printf("Welcome to EE160\n");
  return 0;
}