 #include <stdio.h>

int main()
{
  printf("My name is: Joshua Marre\n");
  printf("My email is:jmarre@hawaii.edu");
  return 0;
  }
